    ; 🐟 для Микроши
    .project hellosha
    .tape microsha-rkm ; формат ленты RKM
    .org 0
prompt  equ 0F89Dh
puts    equ 0F818h

    lxi h, msg
    call puts
    jmp prompt

msg:
    db 1fh,'priwet, mir!',0dh,0ah,0

div16:  
; Подпрограмма деления целых двоичных чисел без знака формата 16:16
; Метод деления  с восстановленем остатка
; Вход HL делимое, ВС - делитель
; Выход DE частное, HL остаток, CY=0 делитель нуль
                xra a
                ora a
                ora c
                rz      ; если делитель = 0
                xchg
                lxi hl,0
                mvi a,16
loop:           push psw
                dad hl
                xra a
                xchg
                dad hl
                xchg
                adc l
                sub c
                mov l,a
                mov a,h
                sbb b
                mov h,a
                inx de
                jnc per
                dad bc
                dcx de
per:            pop psw
                dcr a
                jnz loop
                stc
                ret
                end

