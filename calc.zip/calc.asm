; 🐟 Microsha
                .PROJECT calc
                .TAPE microsha-rkm      ; RKM TAPE FORMAT
        
QUIT            EQU     0F89DH          ; QUIT TO MONITOR
PUTST           EQU     0F818H          ; PUT STRING IN HL
WGETCH          EQU     0F803H          ; WAIT AND GET CHAR TO A
PUTCH            EQU     0F809H          ; PUT CHAR IN C
        
                ORG     0
                CALL    CLS
MAIN:           LXI     H, NEWLINE
                CALL    PUTST
                LXI     H, STARTS
                CALL    PUTST
CONTINUE:       LXI     H, PROMPTS
                CALL    PUTST
                CALL    GETS
                LXI     H, INPBUFFER
                MVI     A, 01BH         ; ESC/AR2 KEY
                CMP     M
                JZ      DONE
                MVI     A, 0H           ; JUST EMPTY STRING
                CMP     M
                JZ      DONE
                LXI     H, NEWLINE
                CALL    PUTST
                ;LXI     H, INPBUFFER
                ;CALL    PUTST
                LXI     H, INPBUFFER   ; Загружаем адрес тестовой строки "A1 FFF"
                CALL    EXTRACT_TWO_HEX        ; Выделяем подстроки в SUBSTR1 и SUBSTR2
                JC      ERROR                   ; Переход если ошибка
                CALL    PARSEST
                
                JMP     NEXT                
ERROR:          LXI     H, ERRORS
                CALL    PUTST                
NEXT:           LXI     H, NEWLINE
                CALL    PUTST

                JMP     CONTINUE

DONE:           JMP     QUIT

; THIS PROCEDURE CLEARS THE SCREEN
CLS:            LXI     H, CLSS
                CALL    PUTST
                RET
CLSS            DB      01FH, 0         ; CLEAR SCREEN CHAR

; INPUT A STRING INTO THE INBUF BUFFER, UP TO 32 CHARACTERS
; USES WGETC (INPUT A CHARACTER, WAITING IN A)
; HL IS THE BUFFER ADDRESS
; C IS THE MAXIMUM STRING LENGTH
GETS:           LXI     H, INPBUFFER  
                MVI     C, 32           ; MAX STRING LENGTH 
GETS10:         CALL    WGETCH     
                MOV     C, A
                CALL    PUTCH
                CPI     0DH             ; ENTER KEY
                JZ      GETS20      
                MOV     M, A            ; SAVE CHAR
                INX     H               ; POINT TO NEXT
                DCR     C               
                JNZ     GETS10          
GETS20:         MVI     M, 0            ; ADD TRAILING ZERO
                RET            
INPBUFFER       DS      33              ; STRING BUFFER + 1 BUTE FOR THE TRAILING 0

PARSEST:         
                
                RET
                
PROMPTS         DB      023H, 0         ; HASH CHAR
NEWLINE         DB      0AH, 0DH, 0
ERRORS          DB      'ERROR!', 0
STARTS          DB      '--HEX CALC--', 0AH, 0DH
                DB      'ENTER TWO HEXADECIMAL NUMBERS SEPARATED BY A SPACE.', 0Ah, 0Dh
                DB      'THE PROGRAM WILL DISPLAY THEIR SUM, DIFFERENCE,', 0AH, 0DH,
                DB      'PRODUCT AND QUOTIENT.', 0AH, 0DH, 0 
                DB      'TO EXIT TO THE MONITOR, PRESS [AR2] OR [ENTER].', 0AH, 0DH, 0
