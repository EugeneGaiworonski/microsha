                .PROJECT calc           ; MICROSHA
                .TAPE microsha-rkm      ; RKM TAPE FORMAT
                ORG     0
MAIN:           
;*******************************************************************************
; PROGRAM ENTRY POINT
;*******************************************************************************
                CALL    CLS
                LXI     H, NEWLINE
                CALL    PUTLN
                LXI     H, STARTS
                CALL    PUTLN
CONTINUE:       LXI     H, PROMPTS
                CALL    PUTLN
                CALL    GETS
                LXI     H, BUFFERLN
                MVI     A, 01BH         ; ESC/AR2 KEY
                CMP     M
                JZ      DONE
                MVI     A, 0H           ; JUST EMPTY STRING
                CMP     M
                JZ      DONE
                LXI     H, NEWLINE
                CALL    PUTLN
                
                ;DEBUG
                LXI     H, BUFFERLN
                CALL    PUTLN
                ;NODEBUG
                
                LXI     D, BUFFERLN
                CALL    PARSELN
                JC      ERROR
                
                JMP     NEXT                
ERROR:          LXI     H, NEWLINE
                CALL    PUTLN
                LXI     H, ERRORS
                CALL    PUTLN                
NEXT:           LXI     H, NEWLINE
                CALL    PUTLN

                JMP     CONTINUE

DONE:           JMP     QUIT

CLS:            
;*******************************************************************************
; CLEAR THE SCREEN
; INPUT: - 
; OUTPUT -
;*******************************************************************************
                LXI     H, CLSLN
                CALL    PUTLN
                RET
CLSLN           DB      01FH, 0         ; CLEAR SCREEN CHAR

GETS:           
;*******************************************************************************
; INPUT A STRING INTO THE INBUF BUFFER, UP TO 32 CHARACTERS
; USES WGETC (INPUT A CHARACTER, WAITING IN A)
; INPUT: HL - THE BUFFER ADDRESS, C - THE MAXIMUM STRING LENGTH
; OUTPUT -
;*******************************************************************************
                LXI     H, BUFFERLN
                MVI     C, 32           ; MAX STRING LENGTH 
GETS10:         CALL    WGETCH     
                MOV     C, A
                CALL    PUTCH
                CPI     0DH             ; ENTER KEY
                JZ      GETS20      
                MOV     M, A            ; SAVE CHAR
                INX     H               ; POINT TO NEXT
                DCR     C               
                JNZ     GETS10          
GETS20:         MVI     M, 0            ; ADD TRAILING ZERO
                RET            
BUFFERLN        DS      33              ; STRING BUFFER + 1 BUTE FOR THE TRAILING 0

PARSELN:         
;*******************************************************************************
; PARSE TWO HEX NUMBERS 
; INPUT: DE - ADDRESS OF A STRING (ASCIZED) CONTAINING TWO 16-BIT HEX NUMBERS 
; SEPARATED BY A SPACE
; OUTPUT: HL - FIRST NUMBER, DE - SECOND NUMBER
; CARRY FLAG SET IF ERROR
;*******************************************************************************
                PUSH    D               ; SAVE A POINTER TO A LINE
                CALL    HEX2WORD        ; CONVERT THE FIRST NUMBER IN HL
                JC      PARSELN10       ; QUIT ON ERROR WITH STC
PARSELN20:                              ;SKIP_SPACES
                LDAX    D               ; LOAD CHAR
                CPI     ' '             ; IS SPACE?
                JNZ     PARSELN30       ; IF NOT PARSE SECOND VALUE
                INX     D               ; NEXT CHAR
                JMP     PARSELN20       ; CONTINUE SKIP SPACES
PARSELN30:      XCHG                    ; HL <-> DE (SAVE FIRST VALUE IN DE)
                CALL    HEX2WORD        ; CONVERT THE SECOND ONE
                JC      PARSELN10       ; QUIT ON ERROR WITH STC
                                        ; SUCCESS
                XCHG                    ; HL <-> DE (RESTORE FIRST VALUE IN HL, SECOND IN DE)
                POP     D               ; RESTORE ORIGINAL POINTER
                ORA     A               ; CLEAR CY
                RET
PARSELN10:      POP     D               ; RESTORE ORIGINAL POINTER
                STC                     ; SET CY
                RET

HEX2WORD:         
;*******************************************************************************
; PARSE ONE 16-BIT NUMBER 
; INPUT: HL - THE STRING ADDRESS 
; OUTPUT: HL - THE BINARY VALUE OF THE NUMBER (MAXIMUM FFFFH)
;*******************************************************************************
                
                RET

;*******************************************************************************
; PROGRAM DATA
;*******************************************************************************
PROMPTS         DB      023H, 0         ; HASH CHAR
NEWLINE         DB      0AH, 0DH, 0
ERRORS          DB      'ERROR!', 0
STARTS          DB      '*** HEX CALC**', 0AH, 0DH
                DB      'ENTER TWO HEXADECIMAL NUMBERS SEPARATED BY A SPACE.', 0Ah, 0Dh
                DB      'THE PROGRAM WILL DISPLAY THEIR SUM, DIFFERENCE,', 0AH, 0DH,
                DB      'PRODUCT AND QUOTIENT.', 0AH, 0DH, 0 
                DB      'TO EXIT TO THE MONITOR, PRESS [AR2] OR [ENTER].', 0AH, 0DH, 0

; BUFFER LENGTH (4 HEX CHARACTERS + TERMINATOR #0)      
SUBLN1          DS      5               ; BUFFER FOR 1 VALUE
SUBLN2          DS      5               ; BUFFER FOR 2 VALUE
VAL1            DW      0               ; 1 VALUE IN BIN
VAL2:           DW      0               ; 2 VALUE IN BIN

QUIT            EQU     0F89DH          ; QUIT TO MONITOR
PUTLN           EQU     0F818H          ; PUT STRING IN HL
WGETCH          EQU     0F803H          ; WAIT AND GET CHAR TO A
PUTCH           EQU     0F809H          ; PUT CHAR IN C