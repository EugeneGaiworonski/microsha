        ; 🐟 для Микроши
        .project calc
        .tape microsha-rkm ; формат ленты RKM
        .org 0
quit    equ     0F89Dh
puts    equ     0F818h
wgetc   equ     0F803h
putc    equ     0F809h
main:   lxi     h, newline
        call    puts
continue:        
        lxi     h, msg1
        call    puts
        call    wgetc
        mov     c, a
        call    putc
        mov     d, c
        lxi     h, newline
        call    puts
        mvi     c, 031h
        mov     a, d
        cmp     c
        
        jnz     continue
        jmp     quit

msg     db 1Fh, 03Eh, 0
msg1    db 03Eh, 0
newline db 0Ah, 0Dh, 0

